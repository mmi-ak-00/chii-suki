// 管理ページ用: 投稿の一覧・非表示・再表示・削除（合言葉 ADMIN_KEY が必要）

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

function same(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

export async function onRequestPost({ request, env }) {
  let body;
  try { body = await request.json(); } catch { return json({ error: "bad request" }, 400); }
  if (!env.ADMIN_KEY) return json({ error: "管理用の合言葉（ADMIN_KEY）がまだ設定されていません。" }, 500);
  if (!same(String(body?.key ?? ""), env.ADMIN_KEY)) {
    await new Promise((r) => setTimeout(r, 800));
    return json({ error: "合言葉がちがいます。" }, 401);
  }
  const id = Number(body.id);
  const bump = env.DB.prepare("UPDATE meta SET v = v + 1 WHERE k='ver'");
  switch (body.action) {
    case "list": {
      const { results } = await env.DB
        .prepare("SELECT id, text, at, hidden FROM posts ORDER BY id DESC LIMIT 1000").all();
      return json({ posts: results });
    }
    case "hide":
    case "show":
      await env.DB.batch([
        env.DB.prepare("UPDATE posts SET hidden=? WHERE id=?").bind(body.action === "hide" ? 1 : 0, id),
        bump,
      ]);
      return json({ ok: true });
    case "delete":
      await env.DB.batch([env.DB.prepare("DELETE FROM posts WHERE id=?").bind(id), bump]);
      return json({ ok: true });
    default:
      return json({ error: "unknown action" }, 400);
  }
}
